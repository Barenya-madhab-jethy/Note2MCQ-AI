# AI Notes & MCQ Generator
Simple hackathon-ready project using Frontend + Python (Flask) + OpenAI/Gemini APIs + SQLite.

## Structure
- app.py                # Flask backend (APIs + web serving)
- db.py                 # Database setup (SQLAlchemy)
- models.py             # SQLAlchemy models
- requirements.txt
- .env.example          # Example environment variables
- templates/index.html  # Frontend (single-page)
- static/css/style.css
- static/js/main.js
- utils/pdf_extract.py  # Helper to extract text from PDF (PyPDF2)

## Setup (local)
1. Create a virtual env:
   ```bash
   python -m venv venv
   source venv/bin/activate  # on Windows: venv\Scripts\activate
   pip install -r requirements.txt
   ```
2. Copy `.env.example` to `.env` and add your OPENAI_API_KEY and/or GEMINI_API_KEY.
3. Run the app:
   ```bash
   export FLASK_APP=app.py
   flask run
   ```
   or
   ```bash
   python app.py
   ```
4. Open http://127.0.0.1:5000

## Notes
- The project uses placeholder functions to call OpenAI/Gemini. Replace them with real calls and install their SDKs.
- For demo during hackathon, you can use a small local stub instead of real API calls.