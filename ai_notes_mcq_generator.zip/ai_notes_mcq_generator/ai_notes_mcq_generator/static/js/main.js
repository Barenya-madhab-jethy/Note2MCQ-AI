async function fetchSaved() {
  const res = await fetch('/api/notes');
  const data = await res.json();
  const ul = document.getElementById('saved-list');
  ul.innerHTML = '';
  data.forEach(n => {
    const li = document.createElement('li');
    li.innerHTML = `<a href="#" data-id="${n.id}">${n.title || ('Note #' + n.id)} - ${new Date(n.created_at).toLocaleString()}</a>`;
    li.querySelector('a').addEventListener('click', async (e) => {
      e.preventDefault();
      const id = e.target.dataset.id;
      const r = await fetch('/api/notes/' + id);
      const note = await r.json();
      document.getElementById('summary').textContent = note.summary || '';
      const mcqs = document.getElementById('mcqs'); mcqs.innerHTML='';
      note.mcqs.forEach(m => {
        const d = document.createElement('div'); d.className='card';
        d.innerHTML = `<b>${m.question}</b><br/>${m.options.map((o,i)=>'<div>'+(String.fromCharCode(65+i))+'. '+o+'</div>').join('')}<div><i>Answer: ${m.answer}</i></div>`;
        mcqs.appendChild(d);
      });
      const flash = document.getElementById('flashcards'); flash.innerHTML='';
      note.flashcards.forEach(f => {
        const d = document.createElement('div'); d.className='card';
        d.innerHTML = `<b>${f.front}</b><div>${f.back}</div>`;
        flash.appendChild(d);
      });
    });
    ul.appendChild(li);
  });
}

document.getElementById('generate-btn').addEventListener('click', async () => {
  const text = document.getElementById('text-input').value;
  const title = document.getElementById('title-input').value;
  if (!text.trim()) { alert('Please enter some text or upload a PDF.'); return; }
  document.getElementById('status').textContent = 'Generating...';
  const res = await fetch('/api/generate', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({text, title}) });
  const j = await res.json();
  document.getElementById('status').textContent = 'Done.';
  document.getElementById('summary').textContent = j.summary.summary || '';
  const mcqs = document.getElementById('mcqs'); mcqs.innerHTML='';
  j.mcqs.forEach(m => {
    const d = document.createElement('div'); d.className='card';
    d.innerHTML = `<b>${m.question}</b><br/>${m.options.map((o,i)=>'<div>'+(String.fromCharCode(65+i))+'. '+o+'</div>').join('')}<div><i>Answer: ${m.answer}</i></div>`;
    mcqs.appendChild(d);
  });
  const flash = document.getElementById('flashcards'); flash.innerHTML='';
  j.flashcards.forEach(f => {
    const d = document.createElement('div'); d.className='card';
    d.innerHTML = `<b>${f.front}</b><div>${f.back}</div>`;
    flash.appendChild(d);
  });
  fetchSaved();
});

document.getElementById('pdf-file').addEventListener('change', async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  const fd = new FormData();
  fd.append('file', f);
  document.getElementById('status').textContent = 'Uploading PDF...';
  const res = await fetch('/api/upload_pdf', { method:'POST', body:fd });
  const j = await res.json();
  document.getElementById('text-input').value = j.text || '';
  document.getElementById('status').textContent = 'PDF uploaded.';
});

// initial
fetchSaved();