import os
import json
import concurrent.futures
import tempfile
from flask import Flask, request, jsonify, render_template, send_from_directory, redirect, url_for, flash, session
from dotenv import load_dotenv
from db import SessionLocal, init_db
from models import Note, MCQ, Flashcard, User
import db as db_module
import uuid
from utils.pdf_extract import extract_text_from_pdf
from werkzeug.security import generate_password_hash, check_password_hash
import openai

load_dotenv()

openai.api_key = os.environ.get('OPENAI_API_KEY')

app = Flask(__name__, static_folder='static', template_folder='templates')
app.secret_key = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
init_db()

# ----- Helper: stub for calling OpenAI -----
# Replace these with actual SDK calls. They return structured outputs.
def call_ai_generate_summaries(text):
    # Placeholder: a very simple rule-based "AI" for offline demo.
    # In production, call OpenAI API here and parse response.
    short = text[:400] + ('...' if len(text) > 400 else '')
    bullets = [line.strip() for line in short.split('.') if line.strip()][:6]
    return {
        'summary': short,
        'bullets': bullets,
        'keywords': bullets[:6]
    }

def call_ai_generate_mcqs(text, num=5):
    prompt = f"Generate {num} MCQs based on the following text. Return as JSON list of objects, each with keys 'question', 'options' (list of 4), 'answer' (index 0-3), 'explanation': {text}"
    try:
        response = openai.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=1000
        )
        content = response.choices[0].message.content
        if content is None:
            return []
        text = content.strip()
        if text.startswith('```json'):
            text = text[7:]
        if text.endswith('```'):
            text = text[:-3]
        return json.loads(text)
    except Exception as e:
        print(f"Error generating MCQs: {e}")
        return []

def call_ai_generate_flashcards(text, num=8):
    prompt = f"Generate {num} flashcards based on the following text. Return as JSON list of objects, each with keys 'front' and 'back': {text}"
    try:
        response = openai.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": prompt}],
            max_tokens=1000
        )
        content = response.choices[0].message.content
        if content is None:
            return []
        text = content.strip()
        if text.startswith('```json'):
            text = text[7:]
        if text.endswith('```'):
            text = text[:-3]
        return json.loads(text)
    except Exception as e:
        print(f"Error generating flashcards: {e}")
        return []

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        db_session = SessionLocal()
        user = db_session.query(User).filter(User.username == username).first()
        db_session.close()

        if user and check_password_hash(user.password, password):
            session['user_id'] = user.id
            session['username'] = user.username
            return redirect(url_for('index'))
        flash('Invalid username or password')

    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')

        db_session = SessionLocal()
        existing_user = db_session.query(User).filter((User.username == username) | (User.email == email)).first()

        if existing_user:
            db_session.close()
            flash('Username or email already exists')
            return render_template('login.html')

        hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
        new_user = User(username=username, email=email, password=hashed_password)
        db_session.add(new_user)
        db_session.commit()
        db_session.close()

        flash('Registration successful! Please login.')
        return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

# ----- Routes -----
@app.route('/')
def index():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('index.html')

@app.route('/api/generate', methods=['POST'])
def generate():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    data = request.get_json() or {}
    text = data.get('text', '').strip()
    title = data.get('title', '')[:255] or None
    if not text:
        return jsonify({'error': 'No text provided.'}), 400

    # Call AI (or stub)
    ai_summary = call_ai_generate_summaries(text)

    # Parallelize MCQ and Flashcard generation
    with concurrent.futures.ThreadPoolExecutor() as executor:
        future_mcqs = executor.submit(call_ai_generate_mcqs, text, 5)
        future_flash = executor.submit(call_ai_generate_flashcards, text, 8)
        ai_mcqs = future_mcqs.result()
        ai_flash = future_flash.result()

    # Save to DB
    db_session = SessionLocal()
    note = Note(title=title, content=text, summary=ai_summary.get('summary'))
    db_session.add(note)
    db_session.commit()
    db_session.refresh(note)

    for m in ai_mcqs:
        mcq = MCQ(
            note_id=note.id,
            question=m['question'],
            option_a=m['options'][0],
            option_b=m['options'][1],
            option_c=m['options'][2],
            option_d=m['options'][3],
            answer=m['answer'],
            explanation=m.get('explanation')
        )
        db_session.add(mcq)

    for c in ai_flash:
        fc = Flashcard(note_id=note.id, front=c['front'], back=c['back'])
        db_session.add(fc)

    db_session.commit()
    db_session.close()

    return jsonify({
        'note_id': note.id,
        'summary': ai_summary,
        'mcqs': ai_mcqs,
        'flashcards': ai_flash
    })

@app.route('/api/notes', methods=['GET'])
def list_notes():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    db_session = SessionLocal()
    notes = db_session.query(Note).order_by(Note.created_at.desc()).all()
    out = []
    for n in notes:
        out.append({'id': n.id, 'title': n.title, 'summary': n.summary, 'created_at': n.created_at.isoformat()})
    db_session.close()
    return jsonify(out)

@app.route('/api/notes/<int:note_id>', methods=['GET'])
def get_note(note_id):
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    db_session = SessionLocal()
    n = db_session.query(Note).filter(Note.id==note_id).first()
    if not n:
        db_session.close()
        return jsonify({'error': 'Not found'}), 404
    mcqs = [{'id':m.id,'question':m.question,'options':[m.option_a,m.option_b,m.option_c,m.option_d],'answer':m.answer,'explanation':m.explanation} for m in n.mcqs]
    cards = [{'id':c.id,'front':c.front,'back':c.back} for c in n.flashcards]
    out = {'id': n.id, 'title': n.title, 'content': n.content, 'summary': n.summary, 'mcqs': mcqs, 'flashcards': cards}
    db_session.close()
    return jsonify(out)

@app.route('/api/upload_pdf', methods=['POST'])
def upload_pdf():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401

    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    f = request.files['file']
    if f.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    # save temporarily
    tmp_path = os.path.join(tempfile.gettempdir(), f'{uuid.uuid4().hex}.pdf')
    f.save(tmp_path)
    text = extract_text_from_pdf(tmp_path)
    try:
        os.remove(tmp_path)
    except:
        pass
    return jsonify({'text': text})

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=int(os.environ.get('PORT', 5000)))
